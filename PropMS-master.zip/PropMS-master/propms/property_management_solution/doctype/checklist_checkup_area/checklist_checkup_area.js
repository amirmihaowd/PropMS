// Copyright (c) 2018, Aakvatech and contributors
// For license information, please see license.txt

frappe.ui.form.on('Checklist Checkup Area', {
	refresh: function(frm) {

	}
});
