// Copyright (c) 2019, Aakvatech and contributors
// For license information, please see license.txt

frappe.ui.form.on('Outsource Contact', {
	refresh: function(frm) {

	}
});
