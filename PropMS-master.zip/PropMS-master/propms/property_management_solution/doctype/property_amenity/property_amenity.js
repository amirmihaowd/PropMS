// Copyright (c) 2018, Aakvatech and contributors
// For license information, please see license.txt

frappe.ui.form.on('Property Amenity', {
	refresh: function(frm) {

	}
});
