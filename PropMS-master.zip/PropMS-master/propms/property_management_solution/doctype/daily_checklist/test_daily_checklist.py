# -*- coding: utf-8 -*-
# Copyright (c) 2018, Aakvatech and Contributors
# See license.txt
from __future__ import unicode_literals
import unittest


class TestDailyChecklist(unittest.TestCase):
    pass
