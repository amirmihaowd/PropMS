# -*- coding: utf-8 -*-
# Copyright (c) 2019, Aakvatech and Contributors
# See license.txt
from __future__ import unicode_literals
import unittest


class TestOutsourcingCategory(unittest.TestCase):
    pass
