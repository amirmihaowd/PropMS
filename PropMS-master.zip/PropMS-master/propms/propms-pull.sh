#!/bin/bash

cd apps/propms/
git pull
git status
